# Arduino Wireless Audio/Data Library 
  
This library allows streaming of data/audio from analog inputs via NRF24L01 radio modules
See the [documentation section](http://tmrh20.github.io/) for more info.
  
  